#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import rospy, cv2, cv_bridge, numpy

from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

#simulatipo:
from sensor_msgs.msg import Image, CameraInfo

#Robot réel: 
#from sensor_msgs.msg import CompressedImage, CameraInfo


class Follower:
	def __init__(self):
		self.bridge = cv_bridge.CvBridge()
		"""
		les topics robot réel:
		/raspicam_node/image/compressed 

		les topices simulations:
		/camera/image

		"""

		self.image_sub = rospy.Subscriber('/camera/image', 
		                                  Image, self.image_callback)

		"""Type de message Image:
		Simulation : Image
		Robot réel : CompressedImage  """

		self.cmd_vel_pub = rospy.Publisher('/cmd_vel',
		                                   Twist, queue_size=1)

		#----objet Twist: 
		self.twist = Twist()

		#----Lidar:
		self.stop_lidar = rospy.Subscriber('/scan', LaserScan, self.laser_callback)

		self.front=1

		self.obstacle=False
		self.obstacle_barriere=False
		self.obstacle_cylinder=False

		self.time=0
		self.front_left=1
		

	def image_callback(self, msg):	
		
		# partie traitement d'image: -------------------------------
		"""
		Simulation: bridge.imgmsg_to_cv2()
		
		Robot réel: bridge.compressed_imgmsg_to_cv2()
		 """
		image = self.bridge.imgmsg_to_cv2(msg,desired_encoding='bgr8')
		hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
		

		#mask orange:
		lower_orange = numpy.array([10,100,20])
		upper_orange = numpy.array([25,255,255])
		mask1 = cv2.inRange(hsv, lower_orange, upper_orange)
		

		#mask vert:
		lower_green = numpy.array([50,100,20])
		upper_green = numpy.array([120,255,255])
		mask2 = cv2.inRange(hsv, lower_green, upper_green)


		# or: 
		"""Soit le mask1 ou le mask2 """
		mask=mask1+mask2

		# détecter chaque couleur pour appliquer les vitesse adaptées
		m1=numpy.mean(mask1.flatten())
		m2=numpy.mean(mask2.flatten())

		h, w, d = image.shape


		search_top = int(5*h/6)
		search_bot = int(5*h/6) + 20
		mask[0:search_top, 0:w] = 0
		mask[search_bot:h, 0:w] = 0



		M = cv2.moments(mask)
		if M['m00'] > 0 and not self.obstacle:
			cx = int(M['m10']/M['m00'])
			cy = int(M['m01']/M['m00'])
			cv2.circle(image, (cx, cy), 20, (0,0,255), -1)

			# BEGIN CONTROL
			err = cx - w/2

			"""
			coulour orange:---------------
			la ligne avec moins de virage, une vitesse importante.

			coulour orange:---------------
			la ligne avec plus de virage, une vitesse moins importante.
			"""
			if m1>m2: 
				self.twist.linear.x = 0.35
				self.twist.angular.z = -float(err) / 60
			else:
				self.twist.linear.x = 0.2
				self.twist.angular.z = -float(err) / 60

			self.cmd_vel_pub.publish(self.twist)


		elif self.obstacle:
			""" 
			Détection d'obstacle par le lidar si l'lobsacle est grand (barrière) le robot doit 
			s'arreter, sinon le robot doit contourner l'obstacle.
			"""
			#arret:
			if self.obstacle_barriere:
				self.twist.linear.x = 0
				self.twist.angular.z = 0 
				self.cmd_vel_pub.publish(self.twist)
			
				
			#déviation:
			elif self.obstacle_cylinder:
				print("obstacle cylinder-------")
				if self.front_left < 0.5:
					self.twist.linear.x = 0.25
					self.twist.angular.z += 0.5 
					self.cmd_vel_pub.publish(self.twist)
					print(self.front_left)

				else:
					while(self.time<20000):
						if self.time<5000:
							self.twist.linear.x = 0.1
							self.twist.angular.z -= 0.5 
							self.cmd_vel_pub.publish(self.twist)
							print("gauche +")
						else:
							self.twist.linear.x = 0.25
							self.twist.angular.z = 0
							self.cmd_vel_pub.publish(self.twist)
							print("doite -")

						self.time+=1
		
			

			# END CONTROL
		cv2.imshow("mask",mask)
		cv2.imshow("output", image)
		cv2.waitKey(3)


	def laser_callback(self, msg):
		self.front=numpy.mean(msg.ranges[0:2]+msg.ranges[358:360])
		self.front_left=numpy.mean(msg.ranges[350:360])

		if self.front <= 0.35:
			self.obstacle=True

			if ( msg.ranges[15] >0.1 and msg.ranges[345] >0.1 ) and ( msg.ranges[15] <10 and msg.ranges[345]<10 ):
				print("[ 20° :{},340° :{}]".format(msg.ranges[20],msg.ranges[340]))
				self.obstacle_barriere=True
				self.obstacle_cylinder=False

			else:
				self.obstacle_cylinder=True
				self.obstacle_barriere=False
		else:
			self.obstacle=False
			self.obstacle_barriere=False
			self.obstacle_cylinder=False


			    	   


if __name__ == '__main__':
    try:

        rospy.init_node('follow_line', anonymous=True)
        follower = Follower()

        rospy.spin()      

    except rospy.ROSInterruptException:
        pass


