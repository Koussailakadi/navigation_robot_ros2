#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import sys, termios, tty
import click
from geometry_msgs.msg import Twist  # le type du message de cmd_vel !!!! 
# import the data type expected for the topic

rospy.init_node('mybot_teleop', anonymous=False)  #True pour s'assurer que le noeud a un nom unique 
# ajoute des nombres aléatoires à la fin du nom

testpub = rospy.Publisher('/cmd_vel',Twist,queue_size=1) 
# On declare que notre noeud publi dans le topic cmd_vel 
#queue size : limite la quantité de message en attente a 5, si le subscriber ne recoit pas assez rapidement
# pour eviter de surcharger 

messageTwist = Twist ()   # on créé la variable qui contient le type de message voulu 
#Twist : 2 vector de 3 parametres


rate = rospy.Rate(2) # 10hz taux de passage dans la boucle == > 10 fois par seconde. 
# Arrow keys codes
keys = {'\x1b[A':'up', '\x1b[B':'down', '\x1b[C':'right', '\x1b[D':'left', 's':'stop', 'q':'quit'}



#TEST si les parametres éxistent

if rospy.has_param("teleop/linear_scale"):
	l=rospy.get_param("teleop/linear_scale")
else:
	l=0.5
	
if rospy.has_param("teleop/angular_scale"):
	a=rospy.get_param("teleop/angular_scale")
else:
	a=0.5


while not rospy.is_shutdown():    # on tourne tant que le noeud est en marche et pas en arret
    if __name__ == '__main__':    # signifie que c'est le script principal et non un importe 

    	try:    
    	    # Get character from console
    	    mykey = click.getchar()
    	    if mykey in keys.keys():
    	        char=keys[mykey]
    	    else:
    	    	char=""
    	    

    	    if char == 'up':    # UP key
    	        # Do something
    	        messageTwist.linear.x= l
    	        messageTwist.linear.y= 0
    	        messageTwist.linear.z= 0
    	        messageTwist.angular.x= 0
    	        messageTwist.angular.y= 0
    	        messageTwist.angular.z= 0
    	        testpub.publish(messageTwist)  # avec testpub on publish => messageTwist
            
    	    if char == 'down':  # DOWN key
    	        # Do something
    	        messageTwist.linear.x= -l
    	        messageTwist.linear.y= 0
    	        messageTwist.linear.z= 0
    	        messageTwist.angular.x= 0
    	        messageTwist.angular.y= 0
    	        messageTwist.angular.z= 0
    	        testpub.publish(messageTwist)
            
    	    if char == 'left':  # RIGHT key
    	        # Do something
    	        messageTwist.linear.x= 0
    	        messageTwist.linear.y= 0
    	        messageTwist.linear.z= 0
    	        messageTwist.angular.x= 0
    	        messageTwist.angular.y= 0
    	        messageTwist.angular.z=  a
    	        testpub.publish(messageTwist)
            
    	    if char == 'right': # LEFT
    	        # Do something
    	        messageTwist.linear.x= 0
    	        messageTwist.linear.y= 0
    	        messageTwist.linear.z= 0
    	        messageTwist.angular.x= 0
    	        messageTwist.angular.y= 0
    	        messageTwist.angular.z= -a
    	        testpub.publish(messageTwist)
            
    	    if char == "quit" :  # QUIT
    	        # Do something
    	        messageTwist.linear.x= 0
    	        messageTwist.linear.y= 0
    	        messageTwist.linear.z= 0
    	        messageTwist.angular.x= 0
    	        messageTwist.angular.y= 0
    	        messageTwist.angular.z= 0

            	testpub.publish(messageTwist)
    	   
    	        #break # on sort de la boucle grace a l'import sys

    	    	
    	except rospy.ROSInterruptException:   # si interruption de ROS
    	    pass                       # on fait rien 
