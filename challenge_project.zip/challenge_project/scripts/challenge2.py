#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import numpy as np

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


### initialisation de cmd le message publié dans cmd_vel pour commander le déplacement du robot  
cmd = Twist()
cmd.linear.x = 0
cmd.linear.y = 0
cmd.linear.z = 0
cmd.angular.x = 0
cmd.angular.y = 0
cmd.angular.z = 0


###"publisher vers cmd_vel

def publisher_(msg):

    ### on pulbie dans le cmd_vel pour jouer sur les commandes de déplacement du robot ! 
    pub=rospy.Publisher("cmd_vel",Twist,queue_size=10)
    rate = rospy.Rate(20)
    if not rospy.is_shutdown():
    	rospy.loginfo(msg)
    	pub.publish(msg)
    	rate.sleep()


def callback_(msg):

### VARIABLES contenant les vecteurs des données recupérés par le Lidar sur les differents coté du robot :  front, left , right ,back


    right = np.mean(msg.ranges[215:270])
    left= np.mean(msg.ranges[45:90])
    front = np.mean(msg.ranges[2:6]+msg.ranges[354:358])
    front_left=np.mean(msg.ranges[5])
    front_right=np.mean(msg.ranges[355])
    back = np.mean(msg.ranges[170:190])

# Affichage des données, afin de les observer si on utilise le code dans une fenetre du terminal avec rosrun challenge_project challenge2.py
    tab=[front,right,left,back]
    print(tab)

## SI un obstacle a plus de 0.45 alors on avance tout droit ! 
    if front >0.50:
    	command(1)
## SInon 
    else:
# SI les infos captés par le lidar dans le coté droit du robot sont plus grandes que celles du cotés gauche, on applique la command(4) ==> tourné a droite 
    	if left-right<0:
    		command(3)
    		print("droite")
# SI les infos captés par le lidar dans le coté gauche du robot sont plus grandes que celles du cotés droit, on applique la command(3) ==> tourné a gauche 
    	elif left-right>0:
        	command(2)
        	print("gauche")

    print("\n")

## fonction qui publie dans cmd_vel l'action a effectuer

def command(instruction):


###Commande a appliqué en fonction des cas ou on se trouve : 

    global cmd
#### on avance seulement 

    if instruction ==1 :
    	cmd.linear.x=0.25
    	cmd.angular.z=0
    	publisher_(cmd)


### on tourne a gauche 
    if instruction == 2: # gauche
        cmd.angular.z=cmd.angular.z+0.5
        publisher_(cmd)

### on tourne a droite 
    if instruction == 3: # droite
        cmd.angular.z=cmd.angular.z-0.5
        publisher_(cmd)



########################################listener of /scan ########################################################

def lidar_listener():
## initialisation du noeud challenge2
    rospy.init_node('challenge2', anonymous=True)
### abonnement au /scan topic les données recueillient par le LIDAR 
    rospy.Subscriber('/scan', LaserScan, callback_)
    rospy.spin()

#################################################################################################

if __name__ == '__main__':
    try:
        lidar_listener()

    except rospy.ROSInterruptException:
        pass
