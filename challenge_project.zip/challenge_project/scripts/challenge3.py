#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import numpy as np

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


###cmd de type Twist
cmd = Twist()
cmd.linear.x = 0
cmd.linear.y = 0
cmd.linear.z = 0
cmd.angular.x = 0
cmd.angular.y = 0
cmd.angular.z = 0


###publisher dans le cmd_vel
def publisher_(msg):

    pub=rospy.Publisher("cmd_vel",Twist,queue_size=10)
    rate = rospy.Rate(40)
    if not rospy.is_shutdown():
    	rospy.loginfo(msg)
    	pub.publish(msg)
    	rate.sleep()


def callback_(msg):

    right = np.mean(msg.ranges[285:325])
    left= np.mean(msg.ranges[35:75])
    front_left = np.mean(msg.ranges[4:18])
    front_right=np.mean(msg.ranges[342:356])
    front = np.mean(msg.ranges[4:18]+msg.ranges[342:356])
    tab=[front,right,left]
    print(tab)

###condition sur le coté avant droite et le coté avant gauche pour palier le fait d'avoir un seulf front et avoir des valeur infini d'un coté.
    if front_left>0.55 and front_right>0.55:
    	command(1)
    	
    else :
#### si la moyenne du vecteur du coté droit des données du lidar est plus grand que le coté gauche, on tourne a droite
        if right>left:
        	command(3)
        	print("droite")
#### si la moyenne du vecteur du coté droit des données du lidar est plus petite que le coté droit , on tourne a gauche
        elif right<left:
        	command(2)
        	print("gauche")



def command(instruction):

    global cmd
#### aller tout droit 
    if instruction ==1 : #
    	cmd.linear.x=0.3
    	cmd.angular.z=0
    	publisher_(cmd)


    if instruction == 2: # gauche
        cmd.linear.x=0.05 # on avance legerement
        cmd.angular.z=cmd.angular.z+0.5
        publisher_(cmd)

    if instruction == 3: # droite
    	cmd.linear.x=0.05 #on avance legerement
    	cmd.angular.z=cmd.angular.z-0.5
    	publisher_(cmd)


#### listener vers le lidar

def listener():
    rospy.init_node('challenge3', anonymous=True)
    rospy.Subscriber('/scan', LaserScan, callback_)
    rospy.spin()

########

if __name__ == '__main__':
    try:
        listener()

    except rospy.ROSInterruptException:
        pass
